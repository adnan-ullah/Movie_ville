<template>
<div id = "wrapper"> 

  <nav class="navbar is-transparent">
    <div class = "navbar-brand">
      <router-link to = "/" class="navbar-item has-text-warning-light">
      <!-- <figure class="image is-1">
           <img
      src="https://upload.wikimedia.org/wikipedia/commons/8/81/Port_City_International_University_Logo.png">
        </figure> -->
        
      </router-link>

      <a class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbar-menu" @click="showMobileMenu = !showMobileMenu">
        <span area-hidden = "true"></span>
        <span area-hidden = "true"></span>
        <span area-hidden = "true"></span>
      </a>
    </div>

  <div class = "navbar-menu" id="navbar-menu" v-bind:class = "{'is-active':showMobileMenu}">
    <div class="navbar-end">
      <router-link to = "/" class="navbar-item has-text-warning-light">Home</router-link>
      <router-link to = "/about" class="navbar-item has-text-warning-light">About</router-link>
      <div class="navbar-item">
        <div class="buttons">
            <router-link to="/login" class="button is-light">LOGIN</router-link>
             <router-link to="/register" class="button is-dark">
             <span class="icon"><i class="fas fa-id-card"></i></span>
             <span>REGISTER</span>
             </router-link>
        </div>
    </div>
    </div>
  </div>

  </nav>
  <!-- <section class="section" id="nav_home">

  <div class="topnav">
    
      <a href="/">Home</a>
      <a href="#">The University</a>
      <a href="#">Management</a>
      <a href="#">Admission</a>
      <a href="#">Academic</a>
      <a href="/contact">Contact_Us</a>
    </div>
  </section> -->

  <section class="section">
     <router-view/>
  </section>

  <section class="section">
     <div class="has-background-dark is-small p-2">
       <h2 class="title has-text-white">
          Quick Links
        </h2>
     </div>
      <!-- <section id="footer_top" class = "section">
          <div class="columns is-multiline">
          
            <div class="column is-one-fourth">
              <ul>
                <li> <a href="#">Notice</a></li>
                 <li><a href="#">Registration</a></li>
                 <li><a href="#">Training</a></li>
                 <li><a href="#">Webmail</a></li>
              </ul>
            </div>
            <div class="column is-one-fourth">
              
                <ul>
                <li><a href="#">Alumni</a></li>
               <li> <a href="#">Seminar</a></li>
               <li> <a href="#">Gallery</a></li>
               <li><a href="#">Press Release</a></li>
                </ul>
            </div>
            <div class="column is-one-fourth">
                <ul>
                 <li><a href="#">Faculty</a></li>
                 <li><a href="#">News</a></li>
                <li> <a href="#">Event</a></li>
                <li> <a href="#">Payment Policy</a></li>
                  </ul>
            </div>
            <div class="column is-one-fourth">
                <ul>
               <li>  <a href="#">Partners</a></li>
                <li> <a href="#">Class Schedule</a></li>
                <li> <a href="#">Exam Schedule</a></li>
                <li> <a href="#">Contact_Us</a> </li>
                </ul>
            </div>
       </div>
      </section> -->
      
        <section class="section">
          
          <div class="columns is-multiline">
          
            <div class="column is-one-fourth">
              <h1 class="has-text-white is-size-3 mb-5 has-text-weight-bold">GET IN TOUCH</h1>
              <p class="has-text-white">
              <span class="icon"><i class="fas fa-location-arrow"></i></span> 
              House No: 226, Building Name: JS Kuthir, West Dewannagar, Hathhazari , Chattogram  </p>
              
            </div>
            <div class="column is-1by2 mt-6 p-5">
                <ul>
                 <li>  <span class="icon"><i class="fas fa-phone"></i></span> +88 01783773113</li>
                 
                  <li><span class="icon"><i class="fas fa-mail-bulk"></i></span> saadnanullah@gmail.com</li>
                 
                  </ul>
            </div>
            <!-- <div class="column is-one-third">
             <h1 class="has-text-white is-size-3 mb-5 has-text-weight-bold">USEFUL LINKS</h1>
              <ul>
               <li>  <i class="fas fa-facebook"></i><a href="http://www.ugc.gov.bd/en">University Grants Commission</a></li>
                <li> <a href="http://www.moedu.gov.bd/">Ministry of Education</a></li>
                <li> <a href="http://www.educationboard.gov.bd/">Education Board Bangladesh</a></li>
                <li> <a href="http://www.bangladesh.gov.bd/">Government of Bangladesh</a> </li>
                </ul>
            </div> -->
       </div>
      </section>
     </section>


  <footer class="footer">
    <p class="has-text-centered">Copyright Adnan Ullah</p>
  </footer>
 
  </div>
</template>

<script>
export default{
  data() {
    return {
      showMobileMenu:false,
      
    }
  },
}
</script>


<style lang="scss">
@import '~bulma';

#wrapper{
  width: 100%;
  background-color: rgb(24, 22, 22);
}
ul a,li{
  color: rgb(255, 240, 240);
}
ul a:hover{
   color: rgb(0, 148, 148);
     transition: color 0.5s ease;
}

.is-transparent {
background-color: transparent;
background-image: none;
}
.is-dark-green-bg
{
  background-color: rgb(11, 26, 18);
}
#footer_top{
  background-color: rgb(77, 23, 32);
}



.topnav {
  background-color: rgb(1, 32, 30);
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #e4c40f;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}


.topnav a:hover {
  background-color: rgb(255, 244, 144);
  transition: background-color 2s ease;
  color: black;
}

#wrapper{
   position: absolute;
}

</style>
