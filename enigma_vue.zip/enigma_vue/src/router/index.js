
import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import Product from '../views/Product.vue'
import News from '../views/News.vue'
import Each_News from '../views/Each_News.vue'
import LoginView from '../views/LoginView'
import RegisterView from '../views/RegisterView'
import MovieView from '../views/MovieView'
import Each_Movie from '../views/EachMovie.vue'
import AboutView from '../views/AboutView'
const routes = [
  {
    path: '/',
    name: 'movie',
    component: MovieView,
    props:true
  },

  {
    path: '/subpages/:movie_id',
    name: 'Each_Movie',
    component: Each_Movie,
    props:true
  },


  {
    path: '/login',
    name: 'login',
    component: LoginView,
    props:true
  },
  {
    path: '/register',
    name: 'register',
    component: RegisterView,
    props:true
  },

  
  // {
  //   path: '/pciu',
  //   name: 'HomeView',
  //   component: HomeView,
  //   props:true
  // },

  // {
  //   path: '/subpages/:category_slug/:news_slug',
  //   name: 'Each_News',
  //   component: Each_News,
  //   props:true
  // },
 
  {
    path: '/about',
    name: 'about',
    component: AboutView
 
  },
 
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
  
  
})

export default router
