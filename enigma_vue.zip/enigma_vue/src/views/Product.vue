<template>
  <div class="page-product">
    <div class="columns is-multiline">
      <div class="column is-6">
        <figure class="image mb-6">
          <img v-bind:src="product.get_image" />
        </figure>

        <h1 class="title has-text-grey">{{ product.name }}</h1>
        <p class="subtitle has-text-black">{{ product.description }}</p>
      </div>

      <div class="column is-3">
        <p class="subtitle">INFORMATION</p>
        <p class="subtitle"><strong>Price: </strong>${{ product.price }}</p>

        <div class="field has-addons mt-6">
          <div class="control">
            <input type="number" class="input" min="1" v-model="quantity" />
          </div>

          <div class="control">
            <a class="button is-dark">Add to cart</a>
          </div>
        </div>
      </div>
    
    
      <div class="column is-3">
        <div class="dropdown is-active">
          <div class="dropdown-trigger">
            <button
              class="button"
             
              aria-haspopup="true"
              aria-controls="dropdown-menu"
            >

              <span>Dropdown button</span>
              <span class="icon is-small">
                <i class="fas fa-angle-down" aria-hidden="true"></i>
              </span>
            </button>
          </div>

         
          <div class="dropdown-menu" id="dropdown-menu" role="menu">
           
            <div class="dropdown-content">
              <a href="#" class="dropdown-item"> Dropdown item </a>
              <a class="dropdown-item"> Other dropdown item </a>
              <a href="#" class="dropdown-item is-active">
                Active dropdown item
              </a>
              <a href="#" class="dropdown-item"> Other dropdown item </a>
              <hr class="dropdown-divider" />
              <a href="#" class="dropdown-item"> With a divider </a>
            </div>
         
          </div>
       

        </div>
      </div>
      
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Product",

  data() {
    return {
      product: {},
      quantity: 1,
        ccc : this.$route.params.abc,
       ppp :  this.$route.params.def
    };
  },

  mounted() {
    this.getProducts();
  },

  methods: {
    getProducts() {
     
     

      axios
        .get(`/api/v1/products/${this.ccc}/${this.ppp}/`)
        .then((response) => {
          this.product = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>


