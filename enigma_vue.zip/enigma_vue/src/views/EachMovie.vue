<template>
    <div class="each-news">

      <h1 class="headTitle">
           {{eachMovie.title}}
          </h1>
        
          <p class="has-text-white m-10 is-size-2">Popularity: {{eachMovie.popularity}}</p>
          <p class="has-text-white m-10">Vote Count: {{eachMovie.vote_count}}</p>
          <p class="has-text-danger m-10">Vote average: {{eachMovie.vote_average}}</p>
          <p class="has-text-warning m-10">Release Date: {{eachMovie.release_date}}</p>
         
 
      <section class="hero is-small is-dark mb-6">
       <figure class="image mb-6 is-2by1">
             <img :src="'https://image.tmdb.org/t/p/original'+eachMovie.backdrop_path" />
          </figure>
      </section>
  
      
      <div class="columns is-multiline">
         <h1 class="headTitle_storyline  is-size-10">
            Storyline
          </h1>
        <div>
           <p class="is-size-6 has-text-warning-light has-text-justified mt-6 p-2">{{ eachMovie.overview }}</p>
        </div>
      </div>
  
  
  
      <div class="columns is-multiline">
        <div class="column is-12">
          <!-- <h1 class="hero is-small is-light is-size-10 has-text-centered">
            more...
          </h1> -->
        </div>
  
        <!-- <div
          class="column is-3 p-4" 
          v-for="news_images in news"
          v-bind:key="news_images.id"
         
        >
          <div class="box is-transparent">
            <figure class="image is-4by3">
              <img :src="news_images.get_NewsImage" />
            </figure>
            
          </div>
        </div> -->


      </div>
    </div>
  </template>
  
  <script>
  import axios from "axios";
  
  export default {
    name: "Each_Movie",
  
    data() {
      return {
        eachMovie:{},

        
        slug : this.$route.params.movie_id,
        
  
        
  
      };
    },
  
    components: {},
  
    mounted() {
      window.scrollTo(0, 0);
      this.getMovieData();
    },
  
    methods: {
     

  
      getMovieData() {
        axios
           .get(`/movie/${this.slug}/`)
          .then((response) => {
            this.eachMovie = response.data[0];
            console.log(this.eachMovie)
          })
          .catch((error) => {
            console.log(error);
          });
      },
          
    },
    
  };
  </script>
  
  <style scoped>
  .image {
    margin-top: -1.25rm;
    margin-left: 1.25rm;
    margin-right: -1.25rm;
  }
  
  .top-container {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
  }
  .topnav {
    background-color: #333;
    overflow: hidden;
  }
  .headTitle{
   
    font-size:100px;
    color: rgb(255, 255, 255);
    font-weight: 400;
  }
  .headTitle_storyline{
    font-size:60px;
    color: rgb(255, 248, 143);
    font-weight: 400;
  }
  /* Style the links inside the navigation bar */
  .topnav a {
    float: left;
    color: #e4c40f;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }
  
  /* Change the color of links on hover */
  .topnav a:hover {
    background-color: rgb(255, 234, 41);
    color: black;
  }
  
  /* Add a color to the active/current link */
  .topnav a.active {
    background-color: #04aa6d;
    color: white;
  }
  </style>