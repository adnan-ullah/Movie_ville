<template>
  <div class="each-info">
   
    <div class="a">
      <h1 class="headTitle">Welcome to Movie ville, a site dedicated to the contribution experience at Movie ville. At the moment you can track the status of your new title, episode, trivia, and image update contributions. We will add tracking for other types of data contributions in future updates. Stay tuned!</h1>
    </div>

  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "about",

  data() {
    return {


    };
  },

  components: {},

  mounted() {
  
   
  },

  methods: {
   

  

    
        
  },
  
};
</script>

<style scoped>
.headTitle{
    margin-left: 20px;
    font-size:40px;
    color: rgb(255, 238, 238);
    font-weight: 200;
  }
.a{
  height: 300px;
  background-color: #1a1a1a;
}
.b{
  height: 350px;
  background-color: #fff9e3;
  text-align: center;
 
}
.image {
  margin-top: -1.25rm;
  margin-left: 1.25rm;
  margin-right: -1.25rm;
}

.top-container {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
}
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #e4c40f;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: rgb(255, 234, 41);
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #04aa6d;
  color: white;
}
</style>