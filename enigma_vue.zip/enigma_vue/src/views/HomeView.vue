<template>
  <div class="home">
    <form method="GET" action="{%url 'home'%}">
      <p1 class="title has-text-white ">Welcome to <span class="title has-text-warning-light is-size-2">Port City international University</span></p1
      >
      <!-- <div class="field has-addons mt-6">
      <input
        type="text"
        class="input has-text-white is-transparent"
        placeholder="Search...."
        
      
      />
      </div> -->

      <!-- <div class = "log_reg">
        <router-link to = "/login" class="button is-light m-2">LOGIN</router-link>
        <router-link to = "/register" class="button is-dark mt-2">REGISTER</router-link>
      </div> -->

     
      
    </form>

    <div class="hero is-medium has-background-warning-light mt-6 p-6">
      <form method="GET" action="{%url 'home'%}">
       
        <h2 class="title has-has-text-white has-text-centered">
          Port City International University
        </h2>
        <h5 class="subtitle has-text-has-text-grey-light has-text-centered">
          UGC & Govt. Approved University at Khulshi in Chittagong
        </h5>
      </form>

     
    </div>



   
    <section class="hero is-dark-green-bg mb-6 p-5">
     <div class="columns is-multiline">
      <div class="column is-6 mt-5">
        <img src="https://www.portcity.edu.bd/img/welcome-to-port-city-international-university_banner-welcome-message.jpg"
        class="is-3by1">
      </div>

       <div class="column is-6">
         <h1 class="has-text-danger is-size-1">Welcome to</h1>
         <h1 class="has-text-white is-size-3 mb-5">Port City International University</h1>
      <p class="has-text-justified has-text-white">
        Since the establishment, Port City International University has been focusing on assisting the students in facing the challenges of the ever advancing world. PCIU is a platform where students can rise to the highest level of their capability. It provides an outstanding and supportive environment for both undergraduate and postgraduate students. A talented and dedicated group of academics provide guidance and tutelage the students need to pursue their research and academic goals. The dynamic teaching and learning environment of PCIU brims with talent, creativity and international connections. PCIU has been doing excellent community services by engaging the students
      </p>
      <div class="columns is-centered">
          <div class="column is-3 mt-5">
             <router-link to="/welcome_to" class="button is-white is-outlined">More About Us</router-link>
         </div>
      </div>

      
      </div>

     </div>
    </section>

    <div class="columns is-multiline">
      <div class="column is-12">
        <h1 class="hero is-small is-light is-size-4 has-text-centered">
          NEWS / EVENTS
        </h1>
      </div>

      <div
        class="column is-one-fourth p-4" 
        v-for="news in latestNews"
        v-bind:key="news.id"
      
      >
        <div id= "news_box" class="box">
          <figure class="image mb-4 is-5by4">
            <img :src="news.get_thumbnail" />
          </figure>

          <h3 class="is-size-6 has-text-black"><strong >"{{ news.headline }}"</strong></h3>
          <p class="news_box_p is-size-6">{{ news.description }}</p>

        <div class="bt columns is-centered">
          
          <router-link
            v-bind:to="news.get_absolute_url"
            class="button is-dark is-half"
            >View Details</router-link>
        
        </div>

          
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "HomeView",
 
  data() {
    return {
     
      latestNews:[],
    };
  },

  components: {},

  mounted() {
  
    this.getLatestNews();
  },

  methods: {
   

  getLatestNews() {
      axios
        .get("/api/v1/latest-news/")
        .then((response) => {
          this.latestNews = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },

  },
};


</script>

<style scoped>


.image {
  margin-top: -1.25rm;
  margin-left: 1.25rm;
  margin-right: -1.25rm;
}

.news_box_p{
  color: rgb(255, 65, 65);
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;

}
#news_box{
 
  background: #fff3be;
  height: 450px;
 
  position:relative

}
.bt{
  position: absolute;
  bottom: 15px;
  display: inline-block;
  left: 100px;
  
}


</style>