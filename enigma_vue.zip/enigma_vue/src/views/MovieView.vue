<template>
    <div class="home">
      <form method="GET" action="{%url 'home'%}">
        <h1 class="is-size-4 has-text-white ">Welcome to <span class=" headTitle ">Movie Ville</span></h1
        >
        <!-- <div class="field has-addons mt-6">
        <input
          type="text"
          class="input has-text-white is-transparent"
          placeholder="Search...."
          
        
        />
        </div> -->
<!--   
        <div class = "log_reg">
          <router-link to = "/login" class="button is-light m-2">LOGIN</router-link>
          <router-link to = "/register" class="button is-dark mt-2">REGISTER</router-link>
        </div>
   -->
       
        
      </form>
  
      <div class="hero is-medium  has-background-warning-light mt-6 p-6">
        <form method="GET" action="{%url 'home'%}">
         
          <h2 class="title has-text-dark has-text-centered">
            Touch the most trending movies from here!
          </h2>
          <h5 class="subtitle has-text-danger has-text-centered">
            Movie list with rating providing...
          </h5>
        </form>
  
       
      </div>
  
  
  
     
      <section class="hero  mb-6 p-5">
       <div class="columns is-multiline">
        <div class="column mt-5">
          <img src="https://cdn.wallpapersafari.com/92/82/d6yqTG.jpg"
          class="is-3by1">
        </div>
  
         
  
        
  
       </div>
      </section>
  
      <div class="columns is-multiline">
        <div class="column is-12">
          <h1 class="hero is-small has-text-white is-size-4 has-text-centered">
           Trending Movies
          </h1>
        </div>
  
        <div
          class="column is-2by1" 
          v-for="movie in latestMovie"
          v-bind:key="movie.title"
        
        >
          <div id= "news_box" class="box">
            <figure class="image mb-4 ">
              <img :src="'https://image.tmdb.org/t/p/original'+movie.poster_path"/>
            </figure>
  
            <h3 class="is-size-6 has-text-black"><strong >"{{ movie.original_title }}"</strong></h3>
            <p class="news_box_p is-size-6">{{ movie.overview }}</p>
  
          <div class="bt columns is-centered">
            
            <router-link
              v-bind:to="movie.get_absolute_url"
              class="button is-dark is-half"
              >View Details</router-link>
          
          </div>
  
            
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from "axios";
  
  export default {
    name: "movie",
   
    data() {
      return {
       
        latestMovie:[],
      };
    },
  
    components: {},
  
    mounted() {
    
      this.getLatestMovie();
    },
  
    methods: {
     
  
      getLatestMovie() {
        axios
          .get("http://127.0.0.1:8000/movie/")
          .then((response) => {
            this.latestMovie = response.data;
          })
          .catch((error) => {
            console.log(error);
          });
      },
  
    },
  };
  
  
  </script>
  
  <style scoped>
  
  .headTitle{
    margin-left: 20px;
    font-size:140px;
    color: rgb(252, 255, 78);
    font-weight: bolder;
  }
  .image {
    margin-top: -1.25rm;
    margin-left: 1.25rm;
    margin-right: -1.25rm;
  }
  
  .news_box_p{
    color: rgb(255, 249, 249);
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  
  }
  #news_box{
   
    background: #000000;
    height: 600px;
    width: 300px;
   
    position:relative
  
  }
  .bt{
    position: absolute;
    bottom: 15px;
    display: inline-block;
    left: 100px;
    
  }
  
  
  </style>