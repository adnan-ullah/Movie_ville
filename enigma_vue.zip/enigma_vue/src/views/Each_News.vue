<template>
  <div class="each-news">
    
    <section class="hero is-small is-dark mb-6">
     <figure class="image mb-6 is-2by1">
           <img :src="latestNews.get_image" />
        </figure>
    </section>

    
    <div class="columns is-multiline">
      <h1 class="hero is-small is-light is-size-2 has-text-centered">
         {{latestNews.headline}}
        </h1>
      <div>
         <p class="is-size-6 has-text-warning-light has-text-justified mt-6 p-2">{{ latestNews.description }}</p>
      </div>
    </div>



    <div class="columns is-multiline">
      <div class="column is-12">
        <h1 class="hero is-small is-light is-size-10 has-text-centered">
          more...
        </h1>
      </div>

      <div
        class="column is-3 p-4" 
        v-for="news_images in news"
        v-bind:key="news_images.id"
       
      >
        <div class="box is-transparent">
          <figure class="image is-4by3">
            <img :src="news_images.get_NewsImage" />
          </figure>
          
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Each_News",

  data() {
    return {
      latestNews:{},
      news: {},
      
      category_news : this.$route.params.category_slug,
      news_slug : this.$route.params.news_slug,

      

    };
  },

  components: {},

  mounted() {
    window.scrollTo(0, 0);
    this.getImages();
    this.getNewsData();
  },

  methods: {
   

  getImages() {
      axios
         .get(`/api/v1/news-images/${this.news_slug}/`)
        .then((response) => {
          this.news = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },

    getNewsData() {
      axios
         .get(`/api/v1/news/${this.category_news}/${this.news_slug}`)
        .then((response) => {
          this.latestNews = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },
        
  },
  
};
</script>

<style scoped>
.image {
  margin-top: -1.25rm;
  margin-left: 1.25rm;
  margin-right: -1.25rm;
}

.top-container {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
}
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #e4c40f;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: rgb(255, 234, 41);
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #04aa6d;
  color: white;
}
</style>