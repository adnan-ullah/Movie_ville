<template>
  <div class="page-news">
    <div class="columns is-multiline">
      <div class="column is-6">
        <figure class="image mb-6">
          <img v-bind:src="news.get_image" />
        </figure>

        <h1 class="title has-text-grey">{{ news.headline }}</h1>
        <p class="subtitle has-text-black">{{ news.description }}</p>
      </div>

      <div class="column is-3">
        <h1 class="title has-text-grey">{{ news.headline }}</h1>
        <p class="subtitle"><strong>Description: </strong>{{ news.description }}</p>

        
      </div>
    

    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "News",

  data() {
    return {
      news: {},
      
      
    };
  },

  mounted() {
    this.getNews();
  },

  methods: {
   
  },
};
</script>



<style scoped>
html{ display: grid; height: 100% }
body{
  margin: auto;
  background: linear-gradient(#5e2973, #692424);
}

.a{
  position: absolute;
  width: 204px;
  margin: 0;
  padding: 0;
  list-style-type: none;
  transform-origin: top;
  transition: transform .4s ease-in-out;
  overflow: hidden;
 
}
.slide-enter, .slide-leave-to{
  transform: scaleY(0);
}
</style>
